document.addEventListener("click");{
    alert("Hello! I am an alert box!!");
}